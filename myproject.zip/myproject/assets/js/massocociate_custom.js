$('.input-group.date').datepicker({
			autoclose: true,
		calendarWeeks: false,
		todayHighlight: true,
			
});  
	$('.input-group#datepicker').on('changeDate', function (ev) {
        if ($('.input-group.date').valid()) {
            $('.input-group.date').removeClass('invalid').addClass('success');
        };
    });
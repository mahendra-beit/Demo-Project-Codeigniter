	$(document).ready(function() {


		 
		$('#Others').on('change',function(){
            $('#div_issue_to').html("<input name='Cheque_Issue_To'  id='Cheque_Issue_To' type='text' class='validate' required>");
            $( "#Cheque_Issue_To" ).focus();
        });

        $('#Others').on('change',function(){
            $('#div_issue_to').html("<input name='Cheque_Issue_To'  id='Cheque_Issue_To' type='text' class='validate' required>");
            $( "#Cheque_Issue_To" ).focus();
        });
        $('#Government').on('change',function(){
            $('#div_issue_to').html("<input name='Cheque_Issue_To' id='Cheque_Issue_To' type='text' class='validate' required>");
            $( "#Cheque_Issue_To" ).focus();
        });

        $('#Candidate').on('change',function(){
            if($('#Candidate').val())
                var con_type =$('#Candidate').val();
            if(con_type){
                $.ajax({
                    type: 'GET',
                    url: 'ajax/get-condidate-data.php',
                    data: { con_type: con_type },
                    success: function (response) {
                        $("#Cheque_Issue_To" ).empty();
                        $('#Cheque_Issue_To').html(response);
                        $('#Cheque_Issue_To').material_select();

                    }
                });
            }
        });
        $('#Client').on('change',function(){
            if($('#Client').val())
                var con_type =$('#Client').val();

            //  alert(tcid);
            if(con_type){
                $.ajax({
                    type: 'GET',
                    url: 'ajax/get-condidate-data.php',
                    data: { con_type: con_type },
                    success: function (response) {
                        $("#Cheque_Issue_To" ).empty();
                        $('#Cheque_Issue_To').html(response);
                        $('#Cheque_Issue_To').material_select();

                    }
                });
            }
        });

        $('#company_name').on('change',function(){
            var tcid =$('#company_name').val();
            //alert(tcid);
            if(tcid){
				$.ajax({ 
				type: 'GET', 
				url: 'ajax/get-associate-data.php', 
				data: { tcid: tcid }, 
				dataType: 'json',
				success: function (data) { 
						$('#address').html(data.address);
						$('#Website').val(data.website);
						$('#first_name0').val(data.contact_person);
						$('#work_phon0').val(data.phone);
						$('#designation0').val(data.trade_centre_designation);
						
					}
				});
            }
        });

		$("#associatechkall").change(function(){
			var totchk = $('#totalchkbok').val();
			for(var i=0;i<totchk;i++)
			{
				$("#chk"+i).prop('checked', $(this).prop("checked"));
			}
		});

		var i=0;
		$("#add_row_in_edit").click(function(){


			$('#adrow'+i).html("<td><input name='new_first_name"+i+"' type='text' class='validate'  /></td>\n\\n\
                                    <td><input  name='new_last_name"+i+"' type='text'  class='validate'></td>\n\\n\
                                    <td><input  name='new_designation"+i+"' type='text'  class='validate'></td>\n\
                                    <td><input  name='new_email"+i+"' type='text'  class='validate'></td>\n\
                                    <td><input  name='new_work_phon"+i+"' type='text'  class='validate'></td>\n\
                                    <td><input  name='new_ext_no"+i+"' type='text'  class='validate'></td>\n\
                                    <td><input  name='new_mobile_no"+i+"' type='text'  class='validate'></td></td>");
			$("#add_in_edit_mode").val(i);

			$('#tab_logic1').append('<tr id="adrow'+(i+1)+'"></tr>');
			i++;
		});
		$("#delete_row_in_edit").click(function(){
			if(i>1){
				$("#adrow"+(i-1)).html('');
				i--;
				$("#add_in_edit_mode").val($("#add_in_edit_mode").val() - 1);
			}
		});

		var i=1;
        $("#add_row1").click(function(){


            $('#adrow'+i).html("<td><input name='first_name"+i+"' type='text' class='validate'  /></td>\n\\n\
                                    <td><input  name='last_name"+i+"' type='text'  class='validate'></td>\n\\n\
                                    <td><input  name='designation"+i+"' type='text'  class='validate'></td>\n\
                                    <td><input  name='email"+i+"' type='text'  class='validate'></td>\n\
                                    <td><input  name='work_phon"+i+"' type='text'  class='validate'></td>\n\
                                    <td><input  name='ext_no"+i+"' type='text'  class='validate'></td>\n\
                                    <td><input  name='mobile_no"+i+"' type='text'  class='validate'></td></td>");
            $("#vender_contact_count").val(i);

            $('#tab_logic1').append('<tr id="adrow'+(i+1)+'"></tr>');
            i++;
        });
        $("#delete_row1").click(function(){
            if(i>1){
                $("#adrow"+(i-1)).html('');
                i--;
                $("#vender_contact_count").val($("#vender_contact_count").val() - 1);
            }
        });



        $('#payment_mode').on('change', function () {

        var newurl = $('#payment_mode').val(); // get selected value
       // alert(newurl);
        if (newurl != '') { // require a URL
            $('#add_new').attr('href', newurl);
        }

    });


    $('#jdate,#selected_expirey_date,#agrrement_date,#invoice_raised_date,#Cheque_Dated,#Cheque_DD_Date,#Cheque_DD_Clear_Date,#Agreement_Date,#Agreement_Expiry_Date,#Payment_Date,#Debit_Value_Date,#Credit_Value_Date,#fromdate,#todate').pickadate({
        selectMonths: true, // Creates a dropdown to control month
        selectYears: 15 ,// Creates a dropdown of 15 years to control year
        minDate: +3,
        changeMonth: true,
        changeYear: true,
        formatSubmit: 'yyyy-mm-dd',

    });


	$("input[name=agreement_type]").change(function() {
		var test = $(this).val();
		//alert(test);
		if (test == 'Limited') {
			$("#Selected_Expirey_Date").show();
		}else{
			$("#Selected_Expirey_Date").hide();
		}
		$("#"+test).show();
	});

	
	 

            $('#country_data').on('change',function(){
            	var countryID =$('#country_data').val();
         	 //  alert(countryID);
              	 if(countryID){
                   $.ajax({
                       type:'POST',
                       url:'ajax/get-state-city.php',
                       data:'country_id='+countryID,
                       success:function(response){

						   $('#country_state').html(response);
						   $('#country_state').material_select();

                       }
                   }); 
               }
           });

		   $('#country_state').on('change',function(){
			   var country_state_id =$('#country_state').val();
			   //  alert(country_state_id);
			   if(country_state_id){
				   $.ajax({
					   type:'POST',
					   url:'ajax/get-state-city.php',
					   data:'country_state_id='+country_state_id,
					   success:function(response){
						   //alert(response);
						   $('#state_city').html(response);
						   $('#state_city').material_select();
					   }
				   });
			   }
		   });


		   $('#ac_country_data').on('change',function(){
			   var countryID =$('#ac_country_data').val();
			   //  alert(countryID);
			   if(countryID){
				   $.ajax({
					   type:'POST',
					   url:'ajax/get-state-city.php',
					   data:'country_id='+countryID,
					   success:function(response){

						   $('#ac_country_state').html(response);
						   $('#ac_country_state').material_select();

					   }
				   });
			   }
		   });

		   $('#ac_country_state').on('change',function(){
			   var country_state_id =$('#ac_country_state').val();
			   //  alert(country_state_id);
			   if(country_state_id){
				   $.ajax({
					   type:'POST',
					   url:'ajax/get-state-city.php',
					   data:'country_state_id='+country_state_id,
					   success:function(response){
						   //alert(response);
						   $('#ac_state_city').html(response);
						   $('#ac_state_city').material_select();
					   }
				   });
			   }
		   });



   
			$('#select_emp_for_add_bankac').on('change',function(){
				var select_emp_for_add_bankac =$('#select_emp_for_add_bankac').val();
				//  alert(select_emp_for_add_bankac);
				if(select_emp_for_add_bankac){
					$.ajax({
						type:'POST',
						url:'ajax/get-employee-details.php',
						data:'emp_id='+select_emp_for_add_bankac,
						success:function(response){
                          //  alert(response);
							$('#show_emp_data').html(response);
							//$('#country_state').material_select();

						}
					});
				}
			});

});  //ending of ready(function())




	/*$("#hireheadsform").validate();

		$("#hireforceexpandbenifits").click(function() {
			alert("test");
			$("#companybenifitshireforce").toggle();

		});
		$('#toggle1').click(function() {

			$('.toggle1').toggle();

			return false;

		});*/
	 // toogle for company Benefits 
		/*$("button").click(function(){
			$(".company_benifits_inner").toggle();
		});
*/

		// auto complete data
	/*	$(function() {
			var job_title = [
				"Php Developer",
				"Java Developer",
				"Html Developer",
				"jquery Developer",
				"Css Developer"
			];
			$(".jobtitle").autocomplete({
				source: job_title
			});*/
			//

			//recruiter start

			//number_of_position start

			// currency array
		/*	$(".salary_budget").autocomplete({
				source: "salary_budget.php"
			});*/
			//
			
			/*$(".hireforcenationality").autocomplete({
				source: hireforcenationality
			});
*/
/*
			var number_of_position = [
				"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"
			];
			$(".number_of_position").autocomplete({
				source: number_of_position
			});
			//
			var years_of_expe_min = [
				"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40"
			];
			$(".years_of_expe_min").autocomplete({
				source: years_of_expe_min
			});
			var years_of_expe_max = [
				"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40"
			];
			$(".years_of_expe_max").autocomplete({
				source: years_of_expe_max
			});


			$(".job_function").autocomplete({
				source: "ajax/job_skils.php",
				minLength: 1
			});
			$(".recruiter").autocomplete({
				source: "ajax/recruiter.php",
				minLength: 1
			});

			$(".comapny_name").autocomplete({
				source: "ajax/company_list.php",
				minLength: 1
			});


			$(".industry").autocomplete({
				//source: "industry.php",
				source: "ajax/industry.php",
				minLength: 1
			});

			$(".auto").autocomplete({
				source: "search.php",
				minLength: 1
			});
		});*/
	// 24-4-2016 validate for salary  
	
	//counry state city 

		//counry state city
	

		// salary max min validation
/*
 $("#salary_budget_max").change(function(){
		var a = 0;
        var b = 0;
        var a = parseInt($.trim($("#salary_budget_min").val()));
        var b = parseInt($.trim($("#salary_budget_max").val()));
             //var one = parseInt($('#one').val(),10),
        if ( a < b) 
        {
            //alert("b is big");
			 //alert("Plese Enter Min value");
            $('#salary_budget_max').removeClass('intro');
        }
        else if (a > b) {
            alert("Plese Enter Max value");
            $('#salary_budget_max').addClass('intro');
        }     
    });
	
	$(".SalaryBudget").change(function() {

    $("option:selected", this).each(function() {

        if ($('select[name="salary_budget"]').val() == '') {            
            $('.parannum_permonth').hide();
        } else if ($('select[name="salary_budget"]').val() == '15') {
            $('.parannum_permonth').show();
            $('.permonth').show();
            $('.perannum').hide();
        } else if ($('select[name="salary_budget"]').val() == '22') {
            $('.permonth').show();
            $('.perannum').hide();
        } else if ($('select[name="salary_budget"]').val() == '30') {
            $('.permonth').show();
            $('.perannum').hide();
        } else if ($(' select[name="salary_budget"]').val() == '36') {
            $('.permonth').show();
            $('.perannum').hide();
        } else if ($(' select[name="salary_budget"]').val() == '38') {
            $('.permonth').show();
            $('.perannum').hide();
        } else if ($('select[name="salary_budget"]').val() == '47') {
            $('.permonth').show();
            $('.perannum').hide();
        } else {
            $('.permonth').hide();
            $('.perannum').show();
        }
    });
}).change();

// compnay benifits 
//	joiningticket
 $('select[name="joiningticket"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="joiningticket"]').val() == '1') {
                $('#showjoiningyes').show();
            } else {
                $('#showjoiningyes').hide();
            }
        });
    }).change();
	
	
//	vacationairticket
    $('select[name="vacationairticket"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="vacationairticket"]').val() == 'vacationairticketyes') {
                $('#showvacationairticketyes').show();
            } else {
                $('#showvacationairticketyes').hide();
            }
        });
    }).change();	
	
//	freeaccomadation 
 $('select[name="freeaccomadation"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="freeaccomadation"]').val() == '2') {
                $('#showfreeaccomadationno').show();
            } else {
                $('#showfreeaccomadationno,#showpaidaccomadationyes').hide();
            }
        });
    }).change();
	
	
//	paidaccomadation
$('select[name="paidaccomadation"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="paidaccomadation"]').val() == '1') {
                $('#showpaidaccomadationyes').show();
            } else {
                $('#showpaidaccomadationyes').hide();
            }
        });
    }).change();
	
//	mobileallowance
    $('select[name="mobileallowance"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="mobileallowance"]').val() == '1') {
                $('#showmobileallowanceyes').show();
            } else {
                $('#showmobileallowanceyes').hide();
            }
        });
    }).change();
    $('select[name="carallowance"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="carallowance"]').val() == 'carallowanceyes') {
                $('#cartype').show();
            } else {
                $('#cartype').hide();
            }
        });
    }).change();
    $('select[name="tollfees"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="tollfees"]').val() == 'tollfeesyes') {
                $('#showtollfeesyes').show();
            } else {
                $('#showtollfeesyes').hide();
            }
        });
    }).change();
    $('select[name="carmaintanence"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="carmaintanence"]').val() == 'carmaintanenceyes') {
                $('#showcarmaintanenceyes').show();
            } else {
                $('#showcarmaintanenceyes').hide();
            }
        });
    }).change();
 
    $('select[name="deathinsurance"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="deathinsurance"]').val() == '1') {
                $('#showdeathinsuranceyes').show();
            } else {
                $('#showdeathinsuranceyes').hide();
            }
        });
    }).change();

    $('select[name="cashlessmedical"]').change(function() {

        $("option:selected", this).each(function() {
            if ($(' select[name="cashlessmedical"]').val() == '1') {
                $('#showcashlessmedicalyes').show();
            } else {
                $('#showcashlessmedicalyes').hide();
            }
        });
    }).change();

    $('select[name="selectinterviewlocation"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="selectinterviewlocation"]').val() == 'internationallocation') {
                $('#internationalcountries,#preferedplace').show();
            } else {
                $('#internationalcountries,#preferedplace').hide();
            }
            if ($(' select[name="selectinterviewlocation"]').val() == 'cliantlocation') {
                $('.clientlocation').show();
            } else {
                $('.clientlocation').hide();
            }
        });
    }).change();

	
	
	});         */
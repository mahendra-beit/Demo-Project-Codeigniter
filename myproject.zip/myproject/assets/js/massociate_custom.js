 $(function () 
   {
       $(".AddressCheckBox").on('click', function() {
       
           if ($(".AddressCheckBox").is(":checked")) {
               
               $('#permenantaddress input').each(function(index, element) {
                   
               	var duplicateId = 'D' + $(element).data().identifier,
                       $dupElement = $('input[data-identifier="' + duplicateId + '"]');
                   
                   if($dupElement.length == 1) {
                   	$dupElement.val($(element).val());
                   }
               });
           } else {
           	 $('#presentaddress input').val('');
           }
       });
   });
   function checkOption(obj) 
   {
   	var maritalstatus		=	$("#marital_status").val();
   	if(maritalstatus==2)
   	{
   		$("input#candi_anniversary_date").removeAttr("disabled");
   	}
   	else
   	{
   		$("input#candi_anniversary_date").attr("disabled");
   	}
   
   }
    	$("#employer_type1").click(function()
	{
	$("#end_date").attr("disabled","disabled");	
	$("#end_date").val('Present Working');	
 });
 $("#employer_type2").click(function()
	{
	$("#end_date").removeAttr("disabled");	
	$("#end_date").val('');	
 });
 var i=1;
  $('button#add_field_button').click(function(e) 
  {
            e.preventDefault();
            $('#extract').append('<div id="extract">\
                  <div class="row">\
                     <p>Company Details Add an Employer/Designation to Candidate profile</p>\
                     <div class="input-field col s12 m4">\
                        <input placeholder="" id="company_name" type="text" class="validate">\
                        <label class="active" for="company_name">Company Name</label>\
                     </div>\
                     <div class="input-field col s12 m4">\
                        <input placeholder="" id="position" type="text" class="validate">\
                        <label class="active" for="position">Title / Position</label>\
                     </div>\
                     <div class="input-field col s12 m4">\
                        <input placeholder="" id="job_location" type="text" class="validate">\
                        <label class="active" for="job_location">Job Location</label>\
                     </div>\
                  </div>\
                  <div class="row">\
						<div class="row">\
                     <div class="input-field col s12 col m3" style="margin-top:63px;">\
                        <input placeholder="Start Date"  type="date" class="datepicker" name="start_date" id="start_date" onclick="datepick()">\
                        <label class="active" for="start_date">Duration From</label>\
                     </div>	\
                     <div class="input-field col s12 col m3" style="margin-top:63px;">\
                        <input placeholder="End Date"  type="date" class="datepicker" name="end_date" id="end_date" onclick="datepick()">\
                        <label class="active" for="end_date">To</label>\
                     </div>	\
						<div class="input-field col s12 col m6"> <textarea id="textarea1" class="materialize-textarea" style="max-height:40px;" placeholder=""></textarea>\
							<label for="textarea1">Job Description</label>\
							</div>\
						</div>\
                     </div>\
					 </div>');
					  i++; 
        });
				  function datepick()
					 {
						 $(".datepicker").pickadate
						 ({
							selectMonths: true, // Creates a dropdown to control month
							selectYears: 15 // Creates a dropdown of 15 years to control year
						});
					 }
        $('button#remove_field_button').click(function (e) {
            e.preventDefault();
		
            if ($('#extract .input-field ').length >9) 
			{
                $('#extract').children().last().remove();
            }
			else
			{
					alert("Atleast One Employment Details You Should be Enter");
			}
        });
		$("#current_compensation_type").on('change', function() 
		{
			var cct	=	$("#current_compensation_type").val();
			if(cct=='2')
			{
				$("#variable_addrow").fadeIn();
			}
			else
			{
				$("#variable_addrow").fadeOut();
			}
		});
		$(".edit").click(function()
		 {
			 $("#candidatereport_div").fadeOut();
			 $("#viewcandidate_div").fadeIn();
		 });
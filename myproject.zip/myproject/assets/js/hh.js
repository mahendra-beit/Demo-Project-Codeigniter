$("#btn_1").click(function(e) {

form_1();

    });

   


/*$("#btn_1").click(function(){
    //alert("demo")
        $("#section_2").show();
        // $("#section_1").hide();
        $("#section_2").scrollTop()+"600px";
        $("#section_2").slideDown("fast");
    });
$("#btn_2").click(function(){
    //alert("demo")
        $("#section_3").show();
         $("#section_3").scrollTop()+"1000px";
        $("#section_3").slideDown("fast");
    });*/

 function form_1() 
    {        


         if (document.form_1.job_title.value == "") 
         {
            $("#title_div_job_title").addClass('has-error');
            $("#title_div_job_title").effect('shake');
            $("#error_msg").html('Position Title Is Mandatory');
             $("#error_msg").addClass('show');
            $("#job_title").focus();
            return false;
         }
          if (document.form_1.no_of_positions.value == "") 
         {          
           
            $("#title_div_no_of_positions").addClass('has-error');
            $("#title_div_no_of_positions").effect('shake');
             $("#error_msg").html('Enter Total Positions');
            $("#no_of_positions").focus();
            return false;
         }

             $("#title_div_job_title").removeClass('has-error');
            $("#error_msg").removeClass('hide');
            return true;
            hireheadsdatasave();
         
       
        
   }


   function hireheadsdatasave()
   {   
      var x =  hireheadsvaluevalidatedata();
      if(x)
      {
            var formn = document.querySelector("#hireheadsvalue");
            var data = new FormData(formn);
            data.append('type', '1');
         
            jQuery.each($('input[name^="document_file"]')[0].files, function(i, file)
            {
                data.append(i, file);
            });
            
            //aler(formn)
            $.ajax
            ({
                url: "../model/hh_m.php",
                data: data,
                type: 'POST',
                cache: false,
                contentType: false,
                processData: false,
                success: function (json)
                 {
                    response = jQuery.parseJSON(json);
                     if (response['STATUS'] == 'OK')
                    {
                       Materialize.toast('Sucessfull Add your data!!!', 3000) // 4000 is the duration of the toast
                       var url = response['DATA'];
                                     //alert(url)
                                     window.location.replace(url);
                    } else
                    {
                       alert('Some Error Occurred!!!');
                    }
                  }
            });             
      }
   }
	$("#btn_back").click(function() 
		{
        	$("#user_data_2").fadeOut('fast');
			$("#search_section").fadeIn('fast');
			$("#user_data_1").fadeIn('fast');
			fnonload();   
        });	


$('#country_data').on('change',function(){               
            var countryID =$('#country_data').val();
            var state =$('#newstate').val(); 
            
         var dataString = 'country_data='+ countryID +'&state='+ state;               

                if(countryID){
                   $.ajax({
                       type:'POST',
                       url:'../includes/ajax/get-state-city.php',
                       data:'country_id='+countryID,     
                  
                       success:function(response){  
                                 
                         $('#country_state').html(response);
			        }
                  
                   }); 
               }
           });

         $('#country_state').on('change',function(){
               
            var country_state_id =$('#country_state').val();             
            if(country_state_id){
               $.ajax({
                  type:'POST',
                  url:'../includes/ajax/get-state-city.php',
                  data:'country_state_id='+country_state_id,
                  success:function(response){
                    
                     $('#state_city').html(response);
                    
                  }
               });
            }
         });


   $(function() {
        $("#fromdate_filter").datepicker({
           
            dateFormat: 'dd-mm-yy',
            changeMonth:true,
            changeYear:true
        });
    
    $("#todate_filter").datepicker({
           
            dateFormat: 'dd-mm-yy',
            changeMonth:true,
            changeYear:true
        });
    
    $("#from_date").datepicker({
            minDate: 0,
            dateFormat: 'dd-mm-yy',
            changeMonth:true,
            changeYear:true
        });
    
        $("#timeline_to_share_cv").datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth:true,
            changeYear:true
        });
    $("#till_date").datepicker({
            minDate: +5,
            dateFormat: 'dd-mm-yy',
            changeMonth:true,
            changeYear:true
        });
    
        $("#mandate_received_on_date").datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth:true,
            changeYear:true
        });
    });

  //Hide Show Data For HH
    $('select[name="joiningticket"]').change(function() {

        $("option:selected", this).each(function() {

            if ($('select[name="joiningticket"]').val() == '1') {
                $('#showjoiningyes').show();
            } else {
                $('#showjoiningyes').hide();
            }
        });
    }).change();

    $('select[name="vacationairticket"]').change(function() {
        $("option:selected", this).each(function() {
            if ($('select[name="vacationairticket"]').val() == '1') {
                $('#showvacationairticketyes').show();
            } else {
                $('#showvacationairticketyes').hide();
            }
        });
    }).change();

    // freeaccomadation 
    $('select[name="freeaccomadation"]').change(function() {
        $("option:selected", this).each(function() {
            if ($('select[name="freeaccomadation"]').val() == '2') {
                $('#showfreeaccomadationno').show();
            } else {
                $('#showfreeaccomadationno,#showpaidaccomadationyes').hide();
            }
        });
    }).change();


    // paidaccomadation
    $('select[name="paidaccomadation"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="paidaccomadation"]').val() == '1') {
                $('#showpaidaccomadationyes').show();
            } else {
                $('#showpaidaccomadationyes').hide();
            }
        });
    }).change();
    // mobileallowance
    $('select[name="mobile_allowance"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="mobile_allowance"]').val() == '1') {
                $('#showmobileallowanceyes').show();
            } else {
                $('#showmobileallowanceyes').hide();
            }
        });
    }).change();
    $('select[name="carallowance"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="carallowance"]').val() == '1') {
                $('#cartype').show();
            } else {
                $('#cartype').hide();
            }
        });
    }).change();
    $('select[name="tollfees"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="tollfees"]').val() == '1') {
                $('#showtollfeesyes').show();
            } else {
                $('#showtollfeesyes').hide();
            }
        });
    }).change();
    $('select[name="carmaintanence"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="carmaintanence"]').val() == '1') {
                $('#showcarmaintanenceyes').show();
            } else {
                $('#showcarmaintanenceyes').hide();
            }
        });
    }).change();

    $('select[name="deathinsurance"]').change(function() {
        $("option:selected", this).each(function() {
            if ($(' select[name="deathinsurance"]').val() == '1') {
                $('#showdeathinsuranceyes').show();
            } else {
                $('#showdeathinsuranceyes').hide();
            }
        });
    }).change();

    $('select[name="cashlessmedical"]').change(function() {

        $("option:selected", this).each(function() {
            if ($(' select[name="cashlessmedical"]').val() == '1') {
                $('#showcashlessmedicalyes').show();
            } else {
                $('#showcashlessmedicalyes').hide();
            }
        });
    }).change();

    $('select[name="selectinterviewlocation"]').change(function() {
        $("option:selected", this).each(function() {

            if ($(' select[name="selectinterviewlocation"]').val() == '1') {
                $('#Client_Location_Place').show();
                $('#International_Location_Place').hide();
            } else if ($(' select[name="selectinterviewlocation"]').val() == '2') {
                $('#International_Location_Place').show();
                $('#Client_Location_Place').hide();
            } else {
                $('#International_Location_Place').hide();
                $('#Client_Location_Place').hide();
            }
        });
    }).change();




//check monthly target popup
var post_data = 'type=5';
$.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
{
	resp = jQuery.parseJSON(json); 
	if(resp['STATUS']=="OK")
	{
		$('#monthly_target_popup').modal( { backdrop: 'static',keyboard: false,show: true }) ;
	}
});



//check monthly target popup revise by TM
var post_data = 'type=4';
$.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
{
	resp = jQuery.parseJSON(json); 
	if(resp['STATUS']=="OK")
	{
				$('#monthly_target_popup_revise').modal( { backdrop: 'static',keyboard: false,show: true }) ;
				data = resp['DATA'];

				var content =  '' ;
			
				for(var i=0;i<data.length;i++)
				{
					
				content += '<tr>';
				content +=	'<td>'+data[i].month+'</td>'	;
				//content +=	'<td >'+data[i].input_5+'</td>'	;
				content +=	'<td>'+data[i].client_amout+'</td>';
				
				content +=	'<td>'+data[i].tm_status+'</td>';

				content +=	'<td>'+data[i].qa_status+'</td>'	;


				content +=	'<td id="approve'+data[i].id+'"><a onclick="approveTargetByRecruiter('+data[i].id+')" ><button type="button" class="btn btn-info btn-sm" aria-label="Left Align">Approve</button></a></td>';
			
			//	content +=	'<td >'+data[i].input_4+'</td>'	;
			
			
				content +=	'</tr>'	;	
					
				}


				$( "#recruiter_revise_table tbody" ).append(content);	
				
				 // $('#recruiter_revise_table').dataTable({
			  //       "order": []
			  //   });

	}
});





//team manager approval check 
var post_data = 'type=9';
$.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
{
	resp = jQuery.parseJSON(json); 
	if(resp['STATUS']=="OK")
	{
		$('#team_manager_approval_pop').modal( { backdrop: 'static',keyboard: false,show: true }) ;

				data = resp['DATA'];
				var content =  '' ;
			
				for(var i=0;i<data.length;i++)
				{
					
				content += '<tr>';

				content +=	'<td style="vertical-align: middle;">'+data[i].name+'</td>'	;
				content +=	'<td style="vertical-align: middle;">'+data[i].input_2+'</td>'	;
				content +=	'<td style="vertical-align: middle;">'+data[i].input_3+'</td>'	;
			//	content +=	'<td style="vertical-align: middle;">'+data[i].input_4+'</td>'	;
			
				content +=	'<td style="vertical-align: middle;">'+data[i].input_6+'</td>';
			  //  content +=	'<td>'+data[i].input_8+'</td>';
				content +=	'<td style="vertical-align: middle;" nowrap>'+data[i].input_7+'</td>';
			
			//	content +=	'<td style="vertical-align: middle;">'+data[i].input_8+'</td>';

			//	content +=	'<td style="vertical-align: middle;">'+data[i].input_5+'</td>'	;

			

				// content +=	'<td>'+data[i].input_8+'</td>';

				content +=	'</tr>'	;	
					
				}
				$( "#team_manager_table tbody" ).append(content);	
				
	}
});


function reviseTarget(id)
{
	var cli_currency = $('#client_revenue_currency'+id).val();
	var cli_amount = $('#client_revenue_target_amount'+id).val();
	var can_currency = $('#candidate_revenue_currency'+id).val();
	var can_amount = $('#candidate_revenue_target_amount'+id).val();


	if (cli_amount < $('#client_revenue_target_amount_hidden'+id).val() ) {
		 $('#client_revenue_target_amount'+id).addClass('error');
		 $('#show_rev_messsage'+id).html('<b style="color:red">Should not be less then base amount.</b>');
		 return false;
	}else {
		//if (cli_amount > $('#client_revenue_target_amount_hidden'+id).val())
 			$('#client_revenue_target_amount'+id).removeClass('error');
		 	$('#show_rev_messsage'+id).html('');
	}


	if (confirm("Are you sure to revise as monthly target ?")) 
	{
		
		  var post_data = 'id='+id+'&type=10&cli_currency='+cli_currency+'&cli_amount='+cli_amount+'&can_currency='+can_currency+'&can_amount='+can_amount;
	//	  alert(post_data);
	      $.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
	      {
	        resp = jQuery.parseJSON(json); 
	        if(resp['STATUS']=="OK")
	        {

	         //  $('#show_message_pop').html('<h3 style="color:green"> Thank you for sumbitting your monthly target.</h3>');

				$('#show_message'+id).html('<span style="color:green">Revised</span>'); 

	       //      setInterval(function(){
			   		// $('#monthly_target_popup').modal('hide') ;
		      //   },4000);

	        }
	      });
	}
}


function reviseTargetByQA(id)
{
	var cli_currency = $('#client_revenue_currency'+id).val();
	var cli_amount = $('#client_revenue_target_amount'+id).val();
	var can_currency = $('#candidate_revenue_currency'+id).val();
	var can_amount = $('#candidate_revenue_target_amount'+id).val();

	if (cli_amount < $('#client_revenue_target_amount_hidden'+id).val() ) {
		 $('#client_revenue_target_amount'+id).addClass('error');
		 $('#show_rev_messsage'+id).html('<b style="color:red">Should not be less then base amount.</b>');
		 //$('#show_rev_messsage'+id).html('<b style="color:red">Revised the amount</b>');
		 return false;
	}else {
		//if (cli_amount > $('#client_revenue_target_amount_hidden'+id).val())
 			$('#client_revenue_target_amount'+id).removeClass('error');
		 	$('#show_rev_messsage'+id).html('');
	}


	if (confirm("Are you sure to revise as monthly target")) 
	{
		
		  var post_data = 'id='+id+'&type=2&cli_currency='+cli_currency+'&cli_amount='+cli_amount+'&can_currency='+can_currency+'&can_amount='+can_amount;
	//	  alert(post_data);
	      $.post('../mmanage_m/manage025_m.php',post_data,function(json)
	      {
	        resp = jQuery.parseJSON(json); 
	        if(resp['STATUS']=="OK")
	        {

	         //  $('#show_message_pop').html('<h3 style="color:green"> Thank you for sumbitting your monthly target.</h3>');

				$('#show_message'+id).html('<span style="color:green">Revised</span>'); 

	       //      setInterval(function(){
			   		// $('#monthly_target_popup').modal('hide') ;
		      //   },4000);

	        }
	      });
	}
}


function approveTargetByQA(id)
{
	if(confirm("Are you sure to approve as monthly target")) 
	{

		  var post_data = 'id='+id+'&type=3';
		  //alert(post_data);
	      $.post('../mmanage_m/manage025_m.php',post_data,function(json)
	      {
	        resp = jQuery.parseJSON(json); 
	        if(resp['STATUS']=="OK")
	        {
	           //monthly_target_popup
	          // $('#monthly_target_popup').modal( { backdrop: 'static',keyboard: false,show: true }) ;

	         //  $('#show_message_pop').html('<h3 style="color:green"> Thank you for sumbitting your monthly target.</h3>');

				$('#show_message'+id).html('<span style="color:green">Approved</span>'); 

	       //      setInterval(function(){
			   		// $('#monthly_target_popup').modal('hide') ;
		      //   },4000);

	        }
	      });
	}
}



function approveTargetByTeamManager(id)
{
	if(confirm("Are you sure to approve as monthly target")) 
	{

		  var post_data = 'id='+id+'&type=11';
		  //alert(post_data);
	      $.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
	      {
	        resp = jQuery.parseJSON(json); 
	        if(resp['STATUS']=="OK")
	        {
	           //monthly_target_popup
	          // $('#monthly_target_popup').modal( { backdrop: 'static',keyboard: false,show: true }) ;

	         //  $('#show_message_pop').html('<h3 style="color:green"> Thank you for sumbitting your monthly target.</h3>');

				$('#show_message'+id).html('<span style="color:green">Approved</span>'); 

	       //      setInterval(function(){
			   		// $('#monthly_target_popup').modal('hide') ;
		      //   },4000);

	        }
	      });
	}
}



function approveTargetByRecruiter(id)
{
	if (confirm("Are you sure to approve as monthly target")) 
	{

		  var post_data = 'id='+id+'&type=8';
		  //alert(post_data);
	      $.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
	      {
	        resp = jQuery.parseJSON(json); 
	        if(resp['STATUS']=="OK")
	        {
	           //monthly_target_popup
	          // $('#monthly_target_popup').modal( { backdrop: 'static',keyboard: false,show: true }) ;

	         //  $('#show_message_pop').html('<h3 style="color:green"> Thank you for sumbitting your monthly target.</h3>');

				//$('#approve'+id).html('<span style="color:green">Approved</span>'); 

	            setInterval(function(){
			   		$('#monthly_target_popup_revise').modal('hide') ;
		        },500);

	        }
	      });
	}
} 

function approveTarget(id)
{
	if (confirm("Are you sure to approve as monthly target")) 
	{

		  var post_data = 'id='+id+'&type=8';
		  //alert(post_data);
	      $.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
	      {
	        resp = jQuery.parseJSON(json); 
	        if(resp['STATUS']=="OK")
	        {
	           //monthly_target_popup
	          // $('#monthly_target_popup').modal( { backdrop: 'static',keyboard: false,show: true }) ;

	         //  $('#show_message_pop').html('<h3 style="color:green"> Thank you for sumbitting your monthly target.</h3>');

				$('#approve'+id).html('<span style="color:green">Approved</span>'); 

	       //      setInterval(function(){
			   		// $('#monthly_target_popup').modal('hide') ;
		      //   },4000);

	        }
	      });
	}
}



function validateTargetByTM(recruiter_id,id)
{
	var post_data = 'recruiter_id='+recruiter_id+'&type=7&input_2='+$('#input_2').val();
	$.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
	{
		resp = jQuery.parseJSON(json); 
		if(resp['STATUS']=="OK")
		{
			var targeted_amount = parseFloat(resp['DATA']);
			var input_amount = parseFloat($('#client_revenue_target_amount'+id).val());
			//alert(targeted_amount);
			if (targeted_amount > 0) 
			{
				if (input_amount < targeted_amount) 
				{
					
					$('#show_rev_messsage'+id).html('<span style="color:red">It can not go below the base amount : <b>'+targeted_amount+'</b></span>');
					$('#client_revenue_target_amount'+id).css("border","1px red solid");
					return false;
				}
				else
				{
					$('#show_rev_messsage'+id).html('');
					$('#client_revenue_target_amount'+id).css("border","1px green solid");
				
				}
			}
			
			
		}

	});
}

function validateTarget()
{
	var post_data = 'type=7&input_2='+$('#input_2').val();
	$.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
	{
		resp = jQuery.parseJSON(json); 
		if(resp['STATUS']=="OK")
		{
			var targeted_amount = parseFloat(resp['DATA']);
			var input_amount = parseFloat($('#input_2').val());

			if (targeted_amount > 0) 
			{
				if (input_amount < targeted_amount) 
				{
					$('#show_error').removeClass('hide');
					$('#show_error').removeClass('alert-info');
					$('#show_error').addClass('alert-danger');
					$('#input_2').css("border","1px red solid");
					$('#show_error').html('Your minimum target should be : '+targeted_amount);
					$('#submitDiv').hide();
					return false
				}
				else
				{
					$('#show_error').addClass('hide');
					$('#show_error').removeClass('alert-danger');
				//	$('#show_error').addClass('alert-info');
					//$('#show_error').html('');
					$('#input_2').css("border","1px #F8F8F8 solid");
				//	$('#show_error').html('Its Look Good');
					$('#submitDiv').show();
				}
			}
			
			
		}

	});
}
/*function alertYes()
{
	return true;
}*/
function alertNo()
{
    $('#submitDiv').removeClass("hide");  
   $('#showAlert').addClass("hide");   
	return false;
}

function getAlert() {

	$('#monthly_client_target').validate();
	if($("#monthly_client_target").valid())
	{
		$('#showAlert').removeClass("hide");  
		$('#submitDiv').addClass('hide');
		$('#yesDiv').removeClass('hide');
		$('#msg').removeClass('hide');
	}
	else
	{
		return false;
	}

	
}

/*function custumAlert(message)
{

	var str = '<div class="btn-group" role="group">';
	 str += '<button type="button" onclick="alertYes()" class="btn btn-success">Yes</button>';
	str += '<button type="button" onclick="alertNo()" id="alert_no" class="btn btn-danger">No</button>';
	str += '</div>';
	$('#show_error').html(message +' '+ str);
}*/

function submitMonthlyTarget()
{
	var input_1 	= $('#input_1').val()		;
	var input_2		= $('#input_2').val()		;
	var input_3 	= $('#input_3').val()		;	
	var input_4 	= $('#input_4').val()		;
	
	//if (confirm("Are you sure to submit as monthly target")) 
			  $('#showAlert').addClass("hide");   

			  var post_data = $('#monthly_client_target').serialize()+'&type=6';
			  //alert(post_data);
		      $.post('../mrecruit_m/mrecruit001_m.php',post_data,function(json)
		      {

		        resp = jQuery.parseJSON(json); 
		        if(resp['STATUS']=="OK")
		        {
		        
		    //       $('#show_message_pop').html('<h3 style="color:green"> Thank you for sumbitting your monthly target.</h3>');

 				   $('#submitDiv').html(''); 
 				   $('#showAlert').addClass('hide');  

		            setInterval(function(){
				   		$('#monthly_target_popup').modal('hide') ;
			        },100);

		        }
		      });
	
}

$(document).ready(function() {

	
}); 


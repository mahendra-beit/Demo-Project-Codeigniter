<?php include_once('admin_header.php');?>
<div class="container">
  <?= form_open_multipart('admin/store_article',['class'=>'form-horizontal']); ?>
  <?=form_hidden('user_id',$this->session->userdata('user_id'));?>
  <fieldset>
    <legend>Add Article</legend>
    <div class="row">
    <div class="col-lg-6">
    <div class="form-group">
      <label for="inputEmail" class="col-lg-2 control-label">Title</label>
      <div class="col-lg-10">
      <?php echo form_input(['name'=>'title','id'=>'title','class'=>'form-control','placeholder'=>'Airticle Title','value'=>set_value('title')]);?>
      <?=form_error('title');?>
       <?php // form_error('username',"<p class='text-danger'>","</p>");?>
      </div>
    </div>
    </div>
    </div>
    <div class="row">
    <div class="col-lg-6">
    <div class="form-group">
      <label for="inputEmail" class="col-lg-2 control-label">Article Image</label>
      <div class="col-lg-10">
      <?php echo form_upload(['name'=>'userfile','id'=>'userfile','class'=>'form-control']);?>
      <?php if(isset($upload_error)) echo $upload_error; //form_error('userfile');?>
       <?php // form_error('username',"<p class='text-danger'>","</p>");?>
      </div>
    </div>
    </div>
    </div>
    <div class="row"> 
    <div class="col-lg-6">
      <div class="form-group">
      <label for="inputPassword" class="col-lg-2 control-label">Article</label>
      <div class="col-lg-10">       
        <?= form_textarea(['name'=>'body','id'=>'body','class'=>'form-control','placeholder'=>'Airticle Body','value'=>set_value('body')]);?>
         <?= form_error('body');?>
         <?php // form_error('password',"<p class='text-danger'>","</p>");?>
      </div>
    </div>
    </div>
    </div>
    <div class="row">
    <div class="col-md-6 col-lg-6">
    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">
       <?= form_submit(['name'=>'submit','class'=>'btn btn-primary','value'=>'Submit']);?>
      </div>
    </div>
    </div>
    </div>
    </div>
    <?php //validation_errors();?>
  </fieldset>
</form>
</div>
<?php include_once('admin_footer.php');?>
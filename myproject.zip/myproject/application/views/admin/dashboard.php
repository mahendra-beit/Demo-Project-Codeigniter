<?php include_once('admin_header.php'); ?>
<h1>Welcome to Admin after login page!</h1>
<div class="container">
<div class="row">
	<div class="col-sm-12 col-lg-6 col-md-6">
	<!-- <a href="<?= base_url('') ?>" class="btn btn-primary btn-lg pull-right">Add Airteicle</a> -->
	<?= anchor('admin/add_article','Add Article',['class'=>'btn-primary btn btn-lg pull-right']);?>
	</div>
</div>
    <?php if($feedback = $this->session->flashdata('feedback')):
$feedback_class = $this->session->flashdata('feedback_class');

    ?>
<div class="alert alert-dismissible <?= $feedback_class; ?>">
<?= $feedback; ?>
</div>
<?php endif; ?>
	<table class="table">
		<thead>
			<th>Sr.No</th>
			<th>Title</th>
			<th>Airticle Body</th>
			<th>Action</th>
		</thead>
		<tbody>

		<?php 
		//if(count($articles));
		//foreach ($articles as $article) ;?>
			<!-- <tr>
				<td>1</td>
				<td>Airticle Title</td>
				<td>
					<button class="btn btn-default">Edit</button>
					<button class="btn btn-danger">Delete</button>
				</td>
			</tr> -->
			<?php 
			# code...
		//}
			//endforech;
		//endif;
		?>

		<?php //	if(count($articles)){ 
			if(count($articles)):
			?>
		<?php 
$count = $this->uri->segment(3,0 );
		foreach ($articles as $article) :?>
			<tr>
				<!-- <td><?=  $article->id; ?></td> -->
				<td><?=  ++$count; ?></td>
				<td><?=  $article->title; ?></td>
				<td><?=  $article->body; ?></td>
				<td>
					<div class="row">
						<div class="col-lg-2">
								<?= anchor("admin/edit_article/{$article->id}",'Edit', ['class'=>'btn btn-primary']) ?>
						</div>
						<div class="col-lg-2">
							<?= form_open('admin/delete_article'),
									form_hidden('article_id',$article->id),
									form_submit(['name'=>'submit','value'=>'Delete','class'=>'btn btn-danger']),
									form_close();
								 ?>
						</div>
						
					</div>
			
				
					<!-- <button class="btn btn-default">Edit</button> -->
					<!-- <button class="btn btn-danger">Delete</button> -->
				</td>
			</tr>
			<?php endforeach; ?>
		<?php else: ?>
				<tr><td colspan="3">No Records Found</td></tr>
		<?php endif;?>
			
		</tbody>
		
	</table>

	<?= $this->pagination->create_links();?>
	 
</div>
<?php include_once('admin_footer.php');

<?php include_once('public_header.php');?>
<div class="container">

  <?= form_open('login/admin_login',['class'=>'form-horizontal']); ?>
  <fieldset>
    <legend>Admin Login</legend>
    <?php if($error = $this->session->flashdata('login_failed')):?>
<div class="alert alert-dismissible alert-danger">
<?php echo $error; ?>
</div>
<?php endif; ?>
    <div class="form-group">
      <label for="inputEmail" class="col-lg-2 control-label">User Name</label>
      <div class="col-lg-10">
      <?php echo form_input(['name'=>'username','id'=>'username','class'=>'form-control','placeholder'=>'User Name','value'=>set_value('username')]);?>
      <?=form_error('username');?>
       <?php // form_error('username',"<p class='text-danger'>","</p>");?>
      </div>
    </div>
      <div class="form-group">
      <label for="inputPassword" class="col-lg-2 control-label">Password</label>
      <div class="col-lg-10">       
        <?= form_password(['name'=>'password','id'=>'password','class'=>'form-control','placeholder'=>'Password','value'=>set_value('password')]);?>
         <?= form_error('password');?>
         <?php // form_error('password',"<p class='text-danger'>","</p>");?>
      </div>
    </div>
  
    
   
    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">

       <!--  <button type="reset" class="btn btn-default">Cancel</button> -->
        <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
        <?= form_reset(['name'=>'reset','class'=>'btn btn-default','value'=>'Reset']);?>
        <?= form_submit(['name'=>'submit','class'=>'btn btn-primary','value'=>'Login']);?>
      </div>
    </div>
    <?php //validation_errors();?>
  </fieldset>
</form>
</div>

<?php include_once('public_footer.php');?>
<?php

$config = [
			'add_article_rules' =>	[
										[
													'field' => 'title',
													'label' => 'Article Title',
													'rules' => 'require|alphadash'

										],
										[
													'field' => 'body',
													'label' => 'Article Title',
													'rules'	=> 'require',
										]
									],
			'admin_login' =>		[
										[
													'field' => 'username',
													'label' => 'User Name',
													'rules' => 'require|alphadash|trim',

										],
										[
													'field' => 'password',
													'label' => 'Password',
													'rules'	=> 'require',
										]
									]
];
?>
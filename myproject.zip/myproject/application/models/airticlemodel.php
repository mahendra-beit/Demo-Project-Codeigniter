<?php
/**
* 
*/
class Airticlemodel extends CI_Model
{ 
	
	/*public function airticle_list(){
		$user_id = $this->session-> userdata('user_id');
		$qry =$this->db
					->select(['body','title','id'])
					->from('article')
					->where('user_id',$user_id)
					->get();
					return $qry->result();
// afte pagination 
	}*/

public function airticle_list($limit,$offset){
		$user_id = $this->session-> userdata('user_id');
		$qry =$this->db
					->select(['body','title','id'])
					->from('article')
					->where('user_id',$user_id)
					->limit($limit,$offset)
					->get();
					return $qry->result();

	}
	public function totalrecord(){
			$user_id = $this->session-> userdata('user_id');
		$qry =$this->db
					->select(['body','title','id'])
					->from('article')
					->where('user_id',$user_id)
					->get();
					return $qry->num_rows();

	
}

public function all_airticle_list($limit,$offset){
		
		$qry =$this->db
					->select(['body','title','id','created_at'])
					->from('article')				
					->limit($limit,$offset)
					->order_by('created_at','DESC')
					->get();
					return $qry->result();

	}
	public function all_totalrecord(){
			
		$qry =$this->db
					->select(['body','title','id'])
					->from('article')					
					->get();
					return $qry->num_rows();

	
}

	public function find($id)
	{
			
		$qry =$this->db
					->from('article')					
					//->select(['body','title','id'])
					->where(['id'=>$id])
					//->from('article')					
					->get();
					if( $qry->num_rows())
						return $qry->row();
					return false;

	
}



/*	public function add_article($post){

		$this->db->insert('article', );
	}*/

	public function add_article($array){


		return $this->db->insert('article',$array );
	}

public function find_article($article_id)
{
$q = $this->db
		->where('id',$article_id)
		->get('article');

		return $q->row();
		//return $q->result();
}

public function update_article($article_id, Array $article)
{
	return $this->db
			->where('id',$article_id)
			->update('article',$article);

}

public function delete_article($article_id)
{
/*	return $this->db
			->where('id',$article_id)
			->delete('article');*/

			return $this->db->delete('article',['id'=>$article_id]);

}

/*public function search($query)
{
     $q = $this->db->from('article')
       ->where("title LIKE '%$query%'")->get();

	return $q->result();

}*/

public function search($query,$limit,$offset)
{
     $q = $this->db->from('article')
       ->where("title LIKE '%$query%'")
       ->limit($limit,$offset)
       ->get();

	return $q->result();

}

public function cout_search_result($query)
{
     $q = $this->db->from('article')
       ->where("title LIKE '%$query%'")->get();

	return $q->num_rows();

}




	/*function __construct(argument)
	{
		# code...
	}*/
}
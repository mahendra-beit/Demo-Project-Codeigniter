<?php 

/**
* Login Model File
*/
class Loginmodel extends CI_Model
{
	
	public function login_valid($username,$password){

// select * from users where username =$
		// $q = $this->db->where('uname'=>$username,'password'=>$password)->get('users');
		$q = $this->db->where('uname',$username)->where('password',$password)->from('users')->get();
		 	if ($q->num_rows()) {
		 		//echo "<pre>";
		 		//print_r($q->result());
		 		//print_r($q->row());
		 		//exit();
		 		//$row = $q->row();
		 		//return $row->id;
		 		return $q->row()->id;
		 		return TRUE;
		 	}else {
		 		return FALSE;
		 	}


		/* $q = $this->db->where('username',$username)->where('password',$password)->from('users')->get();
*/
		/* $q = $this->db->where(['username'=>'$username','password'=>$password])->from('users')->get();*/
		/*$this->db->query("select * from users where username = $usename and password = $password");*/

		//$this->load->$database();
	//1	return TRUE;
	}
	/*function __construct(argument)
	{
		//# code...
		parent::__construct();
		$this->load->database();
	}*/
}
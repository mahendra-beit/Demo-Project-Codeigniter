<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>

	 //$this->load->view('admin/dashboard');
		//$this->load->model('airticlemodel');
		//echo "test";
		//$this->load->model('airticlemodel','art');
		//$this->load->view('admin/dashboard',['arti_cles'=>$articles]);

	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{		
		$this->load->view('public/admin_login');
	}
	public function dashboard()
	{
		$this->load->library('pagination');
	
$config['base_url'] = base_url('admin/dashboard');
$config['per_page'] =2;
$config['total_rows'] = $this->articles->totalrecord();
		$config['full_tag_open'] = "<ul class='pagination'>";
$config['full_tag_close'] ="</ul>";
$config['num_tag_open'] = '<li>';
$config['num_tag_close'] = '</li>';
$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
$config['next_tag_open'] = "<li>";
$config['next_tagl_close'] = "</li>";
$config['prev_tag_open'] = "<li>";
$config['prev_tagl_close'] = "</li>";
$config['first_tag_open'] = "<li>";
$config['first_tagl_close'] = "</li>";
$config['first_link'] = "First Page";
$config['last_link'] = "Last Page";
$config['first_link_open'] = "<li>";
$config['first_link_close'] = "</li>";
$config['last_link_open'] = "<li>";
$config['last_link_close'] = "</li>";
$config['last_tag_open'] = "<li>";
$config['last_tagl_close'] = "</li>";
		$this->pagination->initialize($config);

		$articles =$this->articles->airticle_list($config['per_page'],$this->uri->segment(3));
		$this->load->view('admin/dashboard',['articles'=>$articles]);		
	}
	public function add_article()
	{
			
			$this->load->view('admin/add_article');
	}
	public function store_article()
	{
		$config = [
		'upload_path' =>'./uploads', 
		'allowed_types' =>'gif|jpg|png|jpeg',
		];
		$this->load->library('upload',$config);
	    $post = $this->input->post();
		unset($post['submit']);
		$data =  $this->upload->data();
		echo "<pre>";
		print_r($data);
		print_r($_FILES);
		exit();

		return $this->flashAndRedirect($this->articles->add_article($post),"Articles Added Sucessful","Articles Failed To Add Fail,Plz Try Again");
		/*if($this->airticlemodel->add_article($post))
		{
			$this->session->set_flashdata('feedback',"Articles Add Sucessful");
			$this->session->set_flashdata('feedback_class',"alert-success");		
			return  redirect('admin/dashboard');
		}
		else
		{		
			$this->session->set_flashdata('feedback',"Articles Failed To Add Fail,Plz Try Again");
			$this->session->set_flashdata('feedback_class',"alert-danger");
		}*/
	}
	public function edit_article($article_id)
	{
		$article = $this->articles->find_article($article_id);	
		$this->load->view('admin/edit_article',['article'=>$article]);
	}
	public function update_article($article_id)
	{		
		$post = $this->input->post();
		unset($post['submit']);
		return $this->flashAndRedirect($this->articles->update_article($article_id,$post),"Articles Updated Sucessful","Articles Failed To Update Fail,Plz Try Again");
		/*if($article_id)
		{
					
      		if($this->articles->update_article($article_id,$post))
      		{
      			$this->session->set_flashdata('feedback',"Articles Updated Sucessful");
      			$this->session->set_flashdata('feedback_class',"alert-success");
      			//echo "insert sucessful";
      			return  redirect('admin/dashboard');
      		}
      		else
      		{
      			$this->session->set_flashdata('feedback',"Articles Failed To Update Fail,Plz Try Again");
      			$this->session->set_flashdata('feedback_class',"alert-danger");
      		}
      		return  redirect('admin/dashboard');
		}else{
			   return redirect('admin/edit_article');
		}*/

		//echo $article_id;
	//print_r($post)		;

/*		 	$this->load->library('form_validation'); 
		 	if($this->form_validation->run('add_article_rules'))
		 	{
		 		  $post = $this->input->post();
		 		//  $articles_id = $post['articles_id'];
		      	//	unset($post['submit'],$post['articles_id']);
		 		  	unset($post['submit']);
		 		 	$this->load->model('airticlemodel','articles');
		      		if($this->airticlemodel->update_article($article_id,$post))
		      		{
		      			$this->session->set_flashdata('feedback',"Articles Updated Sucessful");
		      			$this->session->set_flashdata('feedback_class',"alert-success");
		      			//echo "insert sucessful";
		      			return  redirect('admin/dashboard');
		      		}
		      		else
		      		{
		      			$this->session->set_flashdata('feedback',"Articles Failed To Update Fail,Plz Try Again");
		      			$this->session->set_flashdata('feedback_class',"alert-danger");
		      		}
		      		return  redirect('admin/dashboard');
		      }
		      else
		      {
		        return redirect('admin/edit_article');
		      }*/
	}
	public function delete_article(){
		//print_r($this->input->post());
		$article_id = $this->input->post('article_id');
		return $this->flashAndRedirect($this->articles->delete_article($article_id),"Articles Deleted Sucessful","Articles Failed To Deleted Fail,Plz Try Again");
		/*if($article_id){
						
					if($this->articles->delete_article($article_id))
		      		{
		      			$this->session->set_flashdata('feedback',"Articles Deleted Sucessful");
		      			$this->session->set_flashdata('feedback_class',"alert-success");
		      			return  redirect('admin/dashboard');
		      		}
		      		else
		      		{
		      			$this->session->set_flashdata('feedback',"Articles Failed To Deleted Fail,Plz Try Again");
		      			$this->session->set_flashdata('feedback_class',"alert-danger");
		      		}
		      		return  redirect('admin/dashboard');
					}else{
						   return redirect('admin/edit_article');
					}*/
	}
	public function __construct(){
	
		parent::__construct();
		if(!$this->session->userdata('user_id'))
			return redirect('login');
		$this->load->model('airticlemodel','articles');	
		$this->load->helper('form');
		
	}

	private function flashAndRedirect($successful,$successfulMessages,$FailMessages)
	{
		if($successful)
		{
			$this->session->set_flashdata('feedback',$successfulMessages);
		    $this->session->set_flashdata('feedback_class',"alert-success");
		}
		else
		{
			$this->session->set_flashdata('feedback',$FailMessages);
		    $this->session->set_flashdata('feedback_class',"alert-danger");
		}
		return redirect('admin/dashboard');
	}
}
 
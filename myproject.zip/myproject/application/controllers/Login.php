<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{

		if($this->session->userdata('user_id'))
			//echo $this->session->userdata('user_id');
			return redirect('admin/dashboard');

	
		
			//$this->load->view('admin/dashboard');
			

		$this->load->helper('form');
		$this->load->view('public/admin_login');
	}
	public function admin_login()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username','User Name','required|alpha|trim');
		$this->form_validation->set_rules('password','Password','required');

		$this->form_validation->set_error_delimiters("<p class='text-danger'>","</p>");
		//if($this->form_validation->run('admin_login')){
		if($this->form_validation->run()){

			$username = $this->input->post('username');
			$password = $this->input->post('password');

			$this->load->model('loginmodel');
			$login_id = $this->loginmodel->login_valid($username,$password);
			//if($this->loginmodel->login_valid($username,$password))
			if($login_id)
			{
				//$this->load->library('session');
				//$this->session->set_userdata('id',$id);
				$this->session->set_userdata('user_id',$login_id); 
				//$this->load->view('admin/dashboard');
				return redirect('admin/dashboard');
				//echo "done";
			}else{

				$this->session->set_flashdata('login_failed','Invalid Username/Password');
				return redirect('login');

				//echo "fail";

			}
			//echo"validation sucess username is : $username and password is : $password";
		}else{
			//echo"validation faile";
			//echo validation_errors();
			$this->load->view('public/admin_login');
		}
		//$this->form_validation->set_rule('username','User Name','required|alpha|max_length[8]|is_unique[users.uname]');
		//print_r($_POST);
		//echo "admin Login Sucessful";
	}

	public function logout(){
		$this->session->unset_userdata('user_id');
		return redirect('login');
	}
}

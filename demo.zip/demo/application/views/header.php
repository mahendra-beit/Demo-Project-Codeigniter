<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
        <link href="http://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.33/example1/colorbox.min.css" rel="stylesheet"/>
        <script src="https://code.jquery.com/jquery-2.1.1.min.js"/>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.33/jquery.colorbox-min.js"></script>
        <style>#loader{display: none}</style>
        
    </head>
    <body>
        <div class="container">
            <img id="loader" src="<?php echo base_url()?>asset/712.GIF" style="position: absolute; left: 45%; background: #ff9900; padding: 5px; width: 50px; box-shadow: 0px 0px 3px #333"/>
<div class="row clear_fix">
                    <div class="col-md-12" style="position: relative">
                            
                            <style>
                                
                                div #fb, div #gp, div #tw{display: inline-block;}
                                #fb{width: 180px;}
                                #gp{width:  100px;}
                                #tw{width: 180px;}
                            </style>
                           
                        </div>
                    </div>
